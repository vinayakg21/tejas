package com.cg.spring.mvc.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.spring.mvc.beans.Student;

public interface StudentRepository{

	
	public Student addStudent(Student student);
	public List<Student> getStudentList(String city);
	public List<String> getCityList();
	public List<Student> getStudentList();
	public void updateStudent(Student student);
	public void deleteStudent(int id);
	
}

package com.cg.spring.mvc.service;

import java.util.List;

import com.cg.spring.mvc.beans.Student;

public interface StudentService {

	public Student addStudent(Student student);
	public List<Student> getStudentList(String city);
	public List<String> getcityList();
	public List<Student> getStudentList();
	public void updateStudent(Student student);
	public void deleteStudent(int id);
	
}

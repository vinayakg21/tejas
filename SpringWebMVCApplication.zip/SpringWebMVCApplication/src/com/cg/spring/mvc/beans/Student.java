package com.cg.spring.mvc.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
@Entity
@Table(name="student_info")
public class Student {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="student_code")
	private int studentId;
	
	@Column(name="first_name")
	@Pattern(regexp="[A-Z][a-z]{4,}",
			message="Name should start with Upper case and should contain only alphabets.")
	private String firstName;
	@Column(name="last_name")
	private String lastName;
	
	@Column(name="mobile_number")
	@Pattern(regexp="[0-9]{10}",message="Mobile no should be 10 digit")
	private String mobileNo;

	@Min(value=20, message ="Age should be > 20 ")
	@Max(value=50,message ="Age should be < 50")
	private int age;
	@NotNull(message="Please select the gender")
	private String gender;
	@NotNull(message="please select the City")
	private String city;
	
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
}
